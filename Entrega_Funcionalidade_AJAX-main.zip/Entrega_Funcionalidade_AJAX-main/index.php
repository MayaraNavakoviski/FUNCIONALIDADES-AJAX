<?php
//Redireciona para a listagem de ordem serviço
header("Location: ./LPW-Gestao_De_Computadores/view/ordem_servico/home.php");
