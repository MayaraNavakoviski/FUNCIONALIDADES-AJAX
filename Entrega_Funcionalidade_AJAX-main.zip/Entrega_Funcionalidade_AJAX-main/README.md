<img width="671" height="831" alt="image" src="https://github.com/user-attachments/assets/ee322f11-83d0-4e46-9935-2ac7b2e14e56" />

<img width="1410" height="918" alt="image" src="https://github.com/user-attachments/assets/167f3828-f58a-4c9d-a80d-1bbd6a98ee5a" />

