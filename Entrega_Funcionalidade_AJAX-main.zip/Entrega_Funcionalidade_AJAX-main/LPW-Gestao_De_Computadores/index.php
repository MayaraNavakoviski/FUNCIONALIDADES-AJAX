<?php
    //Redireciona para a listagem de clientes
    header("location: ./view/ordem_servico/listar.php");
    