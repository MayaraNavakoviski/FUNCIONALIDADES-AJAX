<?php 
if (!$isHome) {
    echo '</div>'; 
}
?>

</div> <!-- FECHA wrapper flex-1 -->

<footer class="footer-site mt-auto bg-gray-800 text-white">
    <div class="text-center p-4">
        © 2025 Copyright:
        <a class="font-bold">Heloisa Tonin & Mayara Navakoviski</a>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.7/dist/js/bootstrap.bundle.min.js" crossorigin="anonymous"></script>

</body>
</html>
